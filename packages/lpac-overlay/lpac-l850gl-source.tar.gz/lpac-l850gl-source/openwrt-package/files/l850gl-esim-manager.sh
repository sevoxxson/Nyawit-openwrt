#!/bin/sh

LPAC_BIN="${LPAC_BIN:-/usr/bin/lpac}"
NETIFD_IFACE="${NETIFD_IFACE:-modem}"
SWITCH_REFRESH_FLAG="${SWITCH_REFRESH_FLAG:-1}"
DEBUG=0

case "$1" in
        --debug)
                DEBUG=1
                shift
                ;;
        --help|-h)
                echo "Usage: esim [--debug]"
                exit 0
                ;;
esac

if [ "$DEBUG" -eq 1 ]; then
        LPAC_APDU_DEBUG=1
        export LPAC_APDU_DEBUG
fi

if [ -t 1 ]; then
        RED='\033[31m'
        GREEN='\033[32m'
        BLUE='\033[34m'
        CYAN='\033[36m'
        YELLOW='\033[33m'
        MAGENTA='\033[35m'
        BOLD='\033[1m'
        RESET='\033[0m'
        # Extended palette
        BRED='\033[91m'
        BGREEN='\033[92m'
        BYELLOW='\033[93m'
        BBLUE='\033[94m'
        BMAGENTA='\033[95m'
        BCYAN='\033[96m'
        WHITE='\033[97m'
        DIM='\033[2m'
        ITALIC='\033[3m'
        UNDERLINE='\033[4m'
        # Background
        BG_BLUE='\033[44m'
        BG_CYAN='\033[46m'
        BG_MAGENTA='\033[45m'
        BG_RED='\033[41m'
        BG_GREEN='\033[42m'
        BG_YELLOW='\033[43m'
        BG_BLACK='\033[40m'
        BG_WHITE='\033[47m'
else
        RED=''; GREEN=''; BLUE=''; CYAN=''; YELLOW=''; MAGENTA=''
        BOLD=''; RESET=''; BRED=''; BGREEN=''; BYELLOW=''; BBLUE=''
        BMAGENTA=''; BCYAN=''; WHITE=''; DIM=''; ITALIC=''; UNDERLINE=''
        BG_BLUE=''; BG_CYAN=''; BG_MAGENTA=''; BG_RED=''; BG_GREEN=''
        BG_YELLOW=''; BG_BLACK=''; BG_WHITE=''
fi

BOX_WIDTH=65
PROFILE_LINE='+----+------------+----------------------------------+----------+'
DEBUG_PROFILE_LINE='+----+----------+------------------------+------------+------------------+'

has_jq() { command -v jq >/dev/null 2>&1; }

pause() {
        printf '\n%b  Tekan Enter untuk lanjut... %b' "$DIM$ITALIC" "$RESET"
        read -r _
}

run_lpac() { "$LPAC_BIN" "$@"; }

repeat_char() {
        char="$1"; count="$2"; out=''
        while [ "$count" -gt 0 ]; do
                out="$out$char"
                count=$((count - 1))
        done
        printf '%s' "$out"
}

trim_text() {
        text="$1"; max="$2"; len=${#text}
        if [ "$len" -le "$max" ]; then
                printf '%s' "$text"
        else
                cut_len=$((max - 3))
                [ "$cut_len" -lt 1 ] && cut_len=1
                printf '%s...' "$(printf '%s' "$text" | cut -c 1-$cut_len)"
        fi
}

# ─── Box drawing helpers ──────────────────────────────────────────────────────

box_line() {
        printf '%b+%s+%b\n' "$BCYAN" "$(repeat_char '─' $((BOX_WIDTH - 2)))" "$RESET"
}

box_line_thin() {
        printf '%b├%s┤%b\n' "$CYAN" "$(repeat_char '─' $((BOX_WIDTH - 2)))" "$RESET"
}

box_top() {
        printf '%b╔%s╗%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"
}

box_bottom() {
        printf '%b╚%s╝%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"
}

box_sep() {
        printf '%b╠%s╣%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"
}

box_text() {
        text="$1"; color="$2"
        text="$(trim_text "$text" $((BOX_WIDTH - 4)))"
        len=${#text}
        left=$(((BOX_WIDTH - 2 - len) / 2))
        right=$((BOX_WIDTH - 2 - len - left))
        printf '%b║%*s%b%s%b%*s%b║%b\n' \
                "$BCYAN" "$left" '' "$color" "$text" "$BCYAN" "$right" '' "$BCYAN" "$RESET"
}

box_center() {
        text="$1"; color="$2"; border="${3:-$BCYAN}"
        text="$(trim_text "$text" $((BOX_WIDTH - 2)))"
        len=${#text}
        inner=$((BOX_WIDTH - 2))
        left=$(((inner - len) / 2))
        right=$((inner - len - left))
        printf '%b║%b%*s%b%s%b%*s%b║%b\n' \
                "$border" "$RESET" "$left" '' "$color" "$text" "$RESET" "$right" '' "$border" "$RESET"
}

box_item() {
        num="$1"; label="$2"; ncolor="$3"; lcolor="$4"; border="${5:-$BCYAN}"
        label="$(trim_text "$label" 56)"
        printf '%b║%b  %b%s%b  %b%-56s%b  %b║%b\n' \
                "$border" "$RESET" "$ncolor" "$num" "$RESET" \
                "$lcolor" "$label" "$RESET" "$border" "$RESET"
}

box_menu_item() {
        num="$1"; label="$2"; color="$3"
        printf '%b║%b  %b%s%b %b%-56s %b║%b\n' \
                "$BCYAN" "$RESET" \
                "$BOLD$BYELLOW" "$num" "$RESET" \
                "${color:-$WHITE}" "$(trim_text "$label" 56)" \
                "$BCYAN" "$RESET"
}

box_menu_sep() {
        printf '%b║%b%s%b║%b\n' "$BCYAN" "$DIM" "$(repeat_char '.' $((BOX_WIDTH - 2)))" "$BCYAN" "$RESET"
}

# ─── Profile table helpers ────────────────────────────────────────────────────

draw_line() {
        printf '%b%s%b\n' "$CYAN" "$PROFILE_LINE" "$RESET"
}

draw_debug_line() {
        printf '%b%s%b\n' "$CYAN" "$DEBUG_PROFILE_LINE" "$RESET"
}

# ─── Section header ───────────────────────────────────────────────────────────

section_header() {
        title="$1"; color="${2:-$BCYAN}"
        len=${#title}
        pad=$(( (BOX_WIDTH - len - 4) / 2 ))
        printf '\n%b%s %b%b %s %b%b%s%b\n' \
                "$color" "$(repeat_char '─' $pad)" \
                "$BOLD$WHITE" "$BG_BLACK" " $title " \
                "$RESET" "$color" "$(repeat_char '─' $pad)" "$RESET"
}

# ─── Key-value row ────────────────────────────────────────────────────────────

kv_row() {
        key="$1"; val="$2"; kcolor="${3:-$CYAN}"; vcolor="${4:-$WHITE}"
        printf '  %b%-22s%b %b%s%b\n' "$kcolor$BOLD" "$key" "$RESET" "$vcolor" "$val" "$RESET"
}

clear_screen() { clear 2>/dev/null || printf '\033c'; }

show_raw_if_debug() {
        if [ "$DEBUG" -eq 1 ]; then
                printf '\n%b--- RAW LPAC JSON ---%b\n' "$DIM" "$RESET"
                printf '%s\n' "$1" | jq '.'
        fi
}

show_lpac_summary() {
        label="$1"; json="$2"
        # Parse plain fields dari jq tanpa ANSI, warnai di shell via printf %b
        result="$(printf '%s\n' "$json" | jq -r --arg label "$label" '
                select(type=="object" and .type=="lpa") |
                .payload as $p |
                if ($p.code == 0) then
                        "ok\t" + $label + "\t" + ($p.message // "success")
                else
                        "fail\t" + $label + "\t" + (($p.code // "-")|tostring) + "\t" + ($p.message // "-") + "\t" + (($p.data // "")|tostring)
                end' 2>/dev/null | tail -n 1)"
        if [ -z "$result" ]; then
                show_raw_if_debug "$json"
                return
        fi
        status_field="$(printf '%s' "$result" | cut -f1)"
        lbl="$(printf '%s' "$result" | cut -f2)"
        if [ "$status_field" = "ok" ]; then
                msg="$(printf '%s' "$result" | cut -f3)"
                printf '\n%b✔  %s%b\n' "$BGREEN$BOLD" "$lbl" "$RESET"
                printf '%b%-9s%b %b%s%b\n' "$CYAN" "Status :" "$RESET" "$BGREEN" "success" "$RESET"
                printf '%b%-9s%b %s\n'    "$CYAN" "Pesan  :" "$RESET" "$msg"
        else
                code="$(printf '%s' "$result" | cut -f3)"
                msg="$(printf '%s' "$result" | cut -f4)"
                data="$(printf '%s' "$result" | cut -f5)"
                printf '\n%b✘  %s%b\n' "$BRED$BOLD" "$lbl" "$RESET"
                printf '%b%-9s%b %b%s%b\n' "$CYAN" "Status :" "$RESET" "$BRED"    "failed"  "$RESET"
                printf '%b%-9s%b %b%s%b\n' "$CYAN" "Kode   :" "$RESET" "$BYELLOW" "$code"   "$RESET"
                printf '%b%-9s%b %s\n'     "$CYAN" "Pesan  :" "$RESET" "$msg"
                [ -n "$data" ] && printf '%b%-9s%b %s\n' "$CYAN" "Data   :" "$RESET" "$data"
        fi
        show_raw_if_debug "$json"
}

run_lpac_capture() {
        stdout_file="/tmp/esim-lpac-stdout.$$"
        stderr_file="/tmp/esim-lpac-stderr.$$"
        "$LPAC_BIN" "$@" >"$stdout_file" 2>"$stderr_file"
        status=$?
        if [ "$DEBUG" -eq 1 ] && [ -s "$stderr_file" ]; then
                printf '\n%b--- LPAC STDERR ---%b\n' "$DIM" "$RESET"
                cat "$stderr_file"
        fi
        cat "$stdout_file"
        rm -f "$stdout_file" "$stderr_file"
        return $status
}

get_profiles_json() {
        run_lpac profile list 2>/dev/null \
                | jq -c 'select(type=="object" and .type=="lpa") | .payload.data // []' 2>/dev/null \
                | tail -n 1
}

# ─── Profile table ────────────────────────────────────────────────────────────

print_profiles_table() {
        profiles_json="$1"
        printf '\n'

        if [ "$DEBUG" -eq 1 ]; then
                # DEBUG table header: total 65 columns.
                printf '%b╔════╦═════════╦══════════════════════╦══════════╦══════════════╗%b\n' "$CYAN" "$RESET"
                printf '%b║%b %b%-2s%b %b║%b %b%-7s%b %b║%b %b%-20s%b %b║%b %b%-8s%b %b║%b %b%-12s%b %b║%b\n' \
                        "$CYAN" "$RESET" \
                        "$BOLD$WHITE" "No" "$RESET" "$CYAN" \
                        "$RESET" "$BOLD$WHITE" "State" "$RESET" "$CYAN" \
                        "$RESET" "$BOLD$WHITE" "ICCID" "$RESET" "$CYAN" \
                        "$RESET" "$BOLD$WHITE" "Provider" "$RESET" "$CYAN" \
                        "$RESET" "$BOLD$WHITE" "Nickname" "$RESET" "$CYAN" "$RESET"
                printf '%b╠════╬═════════╬══════════════════════╬══════════╬══════════════╣%b\n' "$CYAN" "$RESET"

                total_d="$(printf '%s\n' "$profiles_json" | jq 'length')"
                cur_d=0
                printf '%s\n' "$profiles_json" | jq -r '
                        to_entries[] |
                        [(.key+1),(.value.profileState//"-"),(.value.iccid//"-"),
                         (.value.serviceProviderName//"-"),
                         (.value.profileNickname//.value.profileName//"-")] | @tsv' \
                | while IFS="$(printf '\t')" read -r no state iccid provider name; do
                        cur_d=$((cur_d + 1))
                        if [ "$state" = "enabled" ]; then
                                rc="$BGREEN"; dot="●"; slabel="enabled"
                        else
                                rc="$BBLUE";  dot="○"; slabel="off    "
                        fi
                        name="$(trim_text "$name" 12)"
                        provider="$(trim_text "$provider" 8)"
                        iccid="$(trim_text "$iccid" 20)"
                        printf '%b║%b %b%-2s%b %b║%b ' \
                                "$CYAN" "$RESET" \
                                "$BOLD$BYELLOW" "$no" "$RESET" "$CYAN" "$RESET"
                        printf '%b%b%s %-7s%b' "$rc" "$BOLD" "$dot" "$slabel" "$RESET"
                        printf '%b║%b %b%-20s%b %b║%b %b%-8s%b %b║%b %b%-12s%b %b║%b\n' \
                                "$CYAN" "$RESET" \
                                "$rc" "$iccid" "$RESET" "$CYAN" \
                                "$RESET" "$rc" "$provider" "$RESET" "$CYAN" \
                                "$RESET" "$rc" "$name" "$RESET" "$CYAN" "$RESET"
                        if [ "$cur_d" -lt "$total_d" ]; then
                                printf '%b╠════╬═════════╬══════════════════════╬══════════╬══════════════╣%b\n' "$CYAN" "$RESET"
                        fi
                done
                printf '%b╚════╩═════════╩══════════════════════╩══════════╩══════════════╝%b\n' "$CYAN" "$RESET"

        else
                # Normal table
                printf '%b╔════╦════════════╦══════════════════════════════════╦══════════╗%b\n' "$BCYAN" "$RESET"
                printf '%b║%b %b%-2s%b %b║%b %b%-10s%b %b║%b %b%-32s%b %b║%b %b%-8s%b %b║%b\n' \
                        "$BCYAN" "$RESET" \
                        "$BOLD$WHITE" "No" "$RESET" "$BCYAN" \
                        "$RESET" "$BOLD$WHITE" "Provider" "$RESET" "$BCYAN" \
                        "$RESET" "$BOLD$WHITE" "Nickname / Profile Name" "$RESET" "$BCYAN" \
                        "$RESET" "$BOLD$WHITE" "Status" "$RESET" "$BCYAN" "$RESET"
                printf '%b╠════╬════════════╬══════════════════════════════════╬══════════╣%b\n' "$BCYAN" "$RESET"

                total="$(printf '%s\n' "$profiles_json" | jq 'length')"
                cur=0
                printf '%s\n' "$profiles_json" | jq -r '
                        to_entries[] |
                        [(.key+1),(.value.profileState//"-"),
                         (.value.serviceProviderName//"-"),
                         (.value.profileNickname//.value.profileName//"-")] | @tsv' \
                | while IFS="$(printf '\t')" read -r no state provider name; do
                        cur=$((cur + 1))
                        if [ "$state" = "enabled" ]; then
                                rc="$BGREEN"
                                bg="$BG_GREEN"; label=" ACTIVE "
                        else
                                rc="$BBLUE"
                                bg="$BG_BLUE"; label="  OFF   "
                        fi
                        provider="$(trim_text "$provider" 10)"
                        name="$(trim_text "$name" 32)"
                        printf '%b║%b %b%-2s%b %b║%b %b%-10s%b %b║%b %b%-32s%b %b║%b ' \
                                "$BCYAN" "$RESET" \
                                "$BOLD$BYELLOW" "$no" "$RESET" "$BCYAN" \
                                "$RESET" "$rc" "$provider" "$RESET" "$BCYAN" \
                                "$RESET" "$rc" "$name" "$RESET" "$BCYAN" \
                                "$RESET"
                        printf '%b%b%b%s%b' "$bg" "$BOLD" "$WHITE" "$label" "$RESET"
                        printf ' %b║%b\n' "$BCYAN" "$RESET"
                        if [ "$cur" -lt "$total" ]; then
                                printf '%b╠════╬════════════╬══════════════════════════════════╬══════════╣%b\n' "$BCYAN" "$RESET"
                        fi
                done
                printf '%b╚════╩════════════╩══════════════════════════════════╩══════════╝%b\n' "$BCYAN" "$RESET"
        fi
}

# ─── Select profile ───────────────────────────────────────────────────────────

select_profile() {
        _skip_table="${1:-}"
        profiles_json="$(get_profiles_json)"
        if [ -z "$profiles_json" ]; then
                printf '%bGagal membaca profile list. Pastikan jq terinstall dan LPAC normal.%b\n' "$BRED" "$RESET" >&2
                return 1
        fi

        count="$(printf '%s\n' "$profiles_json" | jq 'length')"
        if [ "$count" -eq 0 ]; then
                printf '%bTidak ada profile eSIM.%b\n' "$BYELLOW" "$RESET"
                return 1
        fi

        if [ "$_skip_table" != "--no-table" ]; then
                print_profiles_table "$profiles_json" >&2
        fi
        printf '\n%b  ➤  Pilih nomor profile: %b' "$BYELLOW$BOLD" "$RESET" >&2
        read -r idx

        case "$idx" in
                ''|*[!0-9]*)
                        printf '%bNomor tidak valid.%b\n' "$BRED" "$RESET" >&2
                        return 1 ;;
        esac

        if [ "$idx" -lt 1 ] || [ "$idx" -gt "$count" ]; then
                printf '%bNomor di luar range.%b\n' "$BRED" "$RESET" >&2
                return 1
        fi

        printf '%s\n' "$profiles_json" | jq -r ".[$((idx - 1))].iccid // .[$((idx - 1))].isdpAid"
}

# ─── Modem helpers ────────────────────────────────────────────────────────────

disconnect_modemmanager() {
        if ! command -v mmcli >/dev/null 2>&1; then return 0; fi
        mmcli -L 2>/dev/null | sed -n 's#.*Modem/\([0-9][0-9]*\).*#\1#p' | while read -r modem_id; do
                [ -n "$modem_id" ] || continue
                mmcli -m "$modem_id" --simple-disconnect >/dev/null 2>&1
        done
}

safe_switch_profile() {
        iccid="$1"
        section_header "SAFE SWITCH PROFILE" "$BYELLOW"
        printf '\n'
        kv_row "Langkah 1" "ifdown $NETIFD_IFACE" "$CYAN" "$WHITE"
        kv_row "Langkah 2" "Disconnect bearer ModemManager" "$CYAN" "$WHITE"
        kv_row "Langkah 3" "Enable profile (refreshflag=$SWITCH_REFRESH_FLAG)" "$CYAN" "$WHITE"
        kv_row "Langkah 4" "ifup $NETIFD_IFACE" "$CYAN" "$WHITE"
        printf '\n  %bTarget ICCID : %b%s%b\n' "$CYAN" "$BOLD$BYELLOW" "$iccid" "$RESET"

        printf '\n%b  ➤  Lanjut switch? [y/N] %b' "$BRED$BOLD" "$RESET"
        read -r yn
        case "$yn" in y|Y) ;; *) return 0 ;; esac

        printf '\n  %b↓%b  Menurunkan interface %b%s%b...\n' "$BYELLOW" "$RESET" "$BOLD" "$NETIFD_IFACE" "$RESET"
        ifdown "$NETIFD_IFACE" >/dev/null 2>&1
        sleep 2

        printf '  %b⊗%b  Disconnect bearer ModemManager...\n' "$BRED" "$RESET"
        disconnect_modemmanager
        sleep 2

        printf '  %b✦%b  Enable profile eSIM...\n' "$BCYAN" "$RESET"
        json="$(run_lpac_capture profile enable "$iccid" "$SWITCH_REFRESH_FLAG")"
        show_lpac_summary "SWITCH PROFILE" "$json"

        printf '\n  %b⏳%b  Menunggu modem memproses SIM refresh...\n' "$BYELLOW" "$RESET"
        sleep 8

        printf '  %b↑%b  Menaikkan interface %b%s%b...\n' "$BGREEN" "$RESET" "$BOLD" "$NETIFD_IFACE" "$RESET"
        ifup "$NETIFD_IFACE" >/dev/null 2>&1

        printf '\n  %b✔%b  Selesai. Jika SIM missing, jalankan menu Recovery.\n' "$BGREEN$BOLD" "$RESET"
        if command -v mmcli >/dev/null 2>&1; then
                mmcli -L 2>/dev/null
        fi
}

# ─── USB recovery ─────────────────────────────────────────────────────────────

find_l850gl_usb_device() {
        for dev in /sys/bus/usb/devices/*; do
                [ -f "$dev/idVendor" ] || continue
                [ -f "$dev/idProduct" ] || continue
                vendor="$(cat "$dev/idVendor" 2>/dev/null)"
                product="$(cat "$dev/idProduct" 2>/dev/null)"
                if [ "$vendor" = "2cb7" ] && [ "$product" = "0007" ]; then
                        basename "$dev"; return 0
                fi
        done
        return 1
}

recover_sim_missing() {
        usb_dev="$(find_l850gl_usb_device)"
        if [ -z "$usb_dev" ]; then
                printf '\n%b  ✘  USB L850GL 2cb7:0007 tidak ditemukan di sysfs.%b\n' "$BRED$BOLD" "$RESET"
                return 1
        fi

        section_header "RECOVERY SIM MISSING" "$BRED"
        printf '\n'
        kv_row "USB Device" "$usb_dev" "$CYAN" "$BYELLOW"
        printf '\n  %b⚠  Recovery akan reset logical USB device.%b\n' "$BYELLOW$BOLD" "$RESET"
        printf '  %bJika kernel macet di USB, mungkin perlu cabut-colok power.%b\n' "$DIM" "$RESET"

        printf '\n%b  ➤  Lanjut recovery? [y/N] %b' "$BRED$BOLD" "$RESET"
        read -r yn
        case "$yn" in y|Y) ;; *) return 0 ;; esac

        printf '\n  %b↓%b  Menurunkan interface...\n' "$BYELLOW" "$RESET"
        ifdown "$NETIFD_IFACE" >/dev/null 2>&1
        disconnect_modemmanager
        /etc/init.d/modemmanager stop >/dev/null 2>&1
        sleep 2

        if [ -w "/sys/bus/usb/devices/$usb_dev/authorized" ]; then
                printf '  %b⊗%b  USB deauthorize %b%s%b...\n' "$BRED" "$RESET" "$BOLD" "$usb_dev" "$RESET"
                echo 0 >"/sys/bus/usb/devices/$usb_dev/authorized" 2>/dev/null
                sleep 4
                printf '  %b✦%b  USB authorize %b%s%b...\n' "$BGREEN" "$RESET" "$BOLD" "$usb_dev" "$RESET"
                echo 1 >"/sys/bus/usb/devices/$usb_dev/authorized" 2>/dev/null
        else
                printf '  %b⚠%b  authorized tidak writable; coba unbind/bind USB...\n' "$BYELLOW" "$RESET"
                echo "$usb_dev" >/sys/bus/usb/drivers/usb/unbind 2>/dev/null
                sleep 4
                echo "$usb_dev" >/sys/bus/usb/drivers/usb/bind 2>/dev/null
        fi

        sleep 8
        printf '  %b▶%b  Memulai ModemManager...\n' "$BCYAN" "$RESET"
        /etc/init.d/modemmanager start >/dev/null 2>&1
        sleep 8
        printf '  %b↑%b  Menaikkan interface...\n' "$BGREEN" "$RESET"
        ifup "$NETIFD_IFACE" >/dev/null 2>&1

        section_header "STATUS SETELAH RECOVERY" "$BGREEN"
        lsusb 2>/dev/null | grep '2cb7:0007'
        mmcli -L 2>/dev/null
        json="$(run_lpac_capture chip info)"
        show_lpac_summary "CHIP INFO" "$json"
}

# ─── Profile menu ─────────────────────────────────────────────────────────────

profile_menu() {
        while :; do
                profiles_json="$(get_profiles_json)"
                if [ -z "$profiles_json" ]; then
                        printf '\n%bGagal membaca profile list.%b\n' "$BRED" "$RESET"
                        pause; return
                fi

                print_profiles_table "$profiles_json"

                printf '\n'
                printf '%b╔%s╗%b\n' "$BMAGENTA" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"
                box_center "AKSI PROFILE" "$BOLD$WHITE$BG_BLACK" "$BMAGENTA"
                printf '%b╠%s╣%b\n' "$BMAGENTA" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"
                box_item "1" "Enable / Switch profile" "$BOLD$BYELLOW" "$WHITE" "$BMAGENTA"
                box_item "2" "Disable profile" "$BOLD$BYELLOW" "$WHITE" "$BMAGENTA"
                box_item "3" "Rename / Nickname profile" "$BOLD$BYELLOW" "$WHITE" "$BMAGENTA"
                box_item "4" "Hapus / Delete profile" "$BOLD$BRED" "$WHITE" "$BMAGENTA"
                box_item "5" "Refresh list" "$BOLD$BCYAN" "$WHITE" "$BMAGENTA"
                box_item "0" "Kembali ke menu utama" "$BOLD$DIM" "$WHITE" "$BMAGENTA"
                printf '%b╚%s╝%b\n' "$BMAGENTA" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"

                printf '\n%b  ➤  Pilih aksi: %b' "$BMAGENTA$BOLD" "$RESET"
                read -r action

                case "$action" in
                        1)
                                iccid="$(select_profile --no-table)" || { pause; continue; }
                                safe_switch_profile "$iccid"
                                pause ;;
                        2)
                                iccid="$(select_profile --no-table)" || { pause; continue; }
                                printf '%b  ➤  Disable ICCID %s ? [y/N] %b' "$BYELLOW$BOLD" "$iccid" "$RESET"
                                read -r yn
                                case "$yn" in
                                        y|Y)
                                                json="$(run_lpac_capture profile disable "$iccid" 0)"
                                                show_lpac_summary "DISABLE PROFILE" "$json" ;;
                                esac
                                pause ;;
                        3)
                                iccid="$(select_profile --no-table)" || { pause; continue; }
                                printf '%b  ➤  Nickname baru: %b' "$BCYAN$BOLD" "$RESET"
                                read -r nickname
                                json="$(run_lpac_capture profile nickname "$iccid" "$nickname")"
                                show_lpac_summary "RENAME PROFILE" "$json"
                                pause ;;
                        4)
                                iccid="$(select_profile --no-table)" || { pause; continue; }
                                printf '%b  ➤  HAPUS profile %s ? Ketik DELETE: %b' "$BRED$BOLD" "$iccid" "$RESET"
                                read -r confirm
                                if [ "$confirm" = "DELETE" ]; then
                                        json="$(run_lpac_capture profile delete "$iccid")"
                                        show_lpac_summary "DELETE PROFILE" "$json"
                                        printf '\n  %b⚠%b  Jalankan Notification Process setelah delete.\n' "$BYELLOW" "$RESET"
                                fi
                                pause ;;
                        5) continue ;;
                        0) return ;;
                        *)
                                printf '%b  Pilihan tidak dikenal.%b\n' "$BRED" "$RESET"
                                pause ;;
                esac
        done
}

# ─── Download profile ─────────────────────────────────────────────────────────

download_profile() {
        printf '\n'
        printf '%b╔%s╗%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"
        box_center "DOWNLOAD eSIM Profile" "$BOLD$BCYAN$BG_BLACK" "$BCYAN"
        printf '%b╠%s╣%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"
        box_item "1" "Activation code / QR  ->  LPA:1\$server\$matching-id\$" "$BOLD$BYELLOW" "$WHITE" "$BCYAN"
        box_item "2" "Pisah SM-DP+ server dan Matching ID" "$BOLD$BYELLOW" "$WHITE" "$BCYAN"
        printf '%b╠%s╣%b\n' "$BCYAN" "$(repeat_char '─' $((BOX_WIDTH - 2)))" "$RESET"
        box_item "0" "Kembali" "$BOLD$DIM" "$WHITE" "$BCYAN"
        printf '%b╚%s╝%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"
        printf '\n%b  ➤  Pilih: %b' "$BCYAN$BOLD" "$RESET"
        read -r mode

        case "$mode" in
                1)
                        printf '%b  ➤  Activation code: %b' "$BGREEN$BOLD" "$RESET"
                        read -r activation_code
                        [ -n "$activation_code" ] || return
                        printf '%b  ➤  Confirmation code (kosong jika tidak ada): %b' "$BGREEN$BOLD" "$RESET"
                        read -r confirmation_code
                        if [ -n "$confirmation_code" ]; then
                                json="$(run_lpac_capture profile download -a "$activation_code" -c "$confirmation_code")"
                        else
                                json="$(run_lpac_capture profile download -a "$activation_code")"
                        fi
                        show_lpac_summary "DOWNLOAD ESIM" "$json"
                        ;;
                2)
                        printf '%b  ➤  SM-DP+ server: %b' "$BGREEN$BOLD" "$RESET"
                        read -r smdp
                        printf '%b  ➤  Matching ID / activation code token: %b' "$BGREEN$BOLD" "$RESET"
                        read -r matching_id
                        printf '%b  ➤  Confirmation code (kosong jika tidak ada): %b' "$BGREEN$BOLD" "$RESET"
                        read -r confirmation_code
                        [ -n "$smdp" ] && [ -n "$matching_id" ] || return
                        if [ -n "$confirmation_code" ]; then
                                json="$(run_lpac_capture profile download -s "$smdp" -m "$matching_id" -c "$confirmation_code")"
                        else
                                json="$(run_lpac_capture profile download -s "$smdp" -m "$matching_id")"
                        fi
                        show_lpac_summary "DOWNLOAD ESIM" "$json"
                        ;;
                0) return ;;
                *) printf '%b  Pilihan tidak dikenal.%b\n' "$BRED" "$RESET" ;;
        esac

        printf '\n  %b⚠%b  Setelah download sukses, jalankan Notification Process.\n' "$BYELLOW$BOLD" "$RESET"
        pause
}

# ─── Notification process ─────────────────────────────────────────────────────

process_notifications() {
        section_header "NOTIFICATION PROCESS" "$BCYAN"
        printf '\n  %bNotification adalah laporan ke server operator%b\n' "$DIM" "$RESET"
        printf '  %bsetelah download/delete/enable/disable profile.%b\n\n' "$DIM" "$RESET"
        printf '  %b⏳%b  Memproses semua pending notification...\n' "$BYELLOW" "$RESET"
        json="$(run_lpac_capture notification process -a -r)"
        show_lpac_summary "NOTIFICATION" "$json"
}

# ─── Info EID ─────────────────────────────────────────────────────────────────

# Helper: print a key-value row inside the info box
_info_kv() {
        key="$1"; val="$2"; kc="${3:-$CYAN}"; vc="${4:-$WHITE}"
        # Truncate value to fit box: BOX_WIDTH - 2 (border) - 2 (pad) - 22 (key) - 1 (space) = 38
        val="$(trim_text "$val" 38)"
        printf '%b║%b  %b%-22s%b %b%-38s%b%b║%b\n' \
                "$BCYAN" "$RESET" \
                "$kc$BOLD" "$key" "$RESET" \
                "$vc" "$val" "$RESET" \
                "$BCYAN" "$RESET"
}

# Helper: separator inside box
_info_sep() {
        printf '%b╟%s╢%b\n' "$BCYAN" "$(repeat_char '─' $((BOX_WIDTH - 2)))" "$RESET"
}

# Helper: centered title row inside box
_info_title() {
        text="$1"; color="${2:-$BYELLOW}"
        len=${#text}
        left=$(( (BOX_WIDTH - 2 - len) / 2 ))
        right=$((BOX_WIDTH - 2 - len - left))
        printf '%b║%b%b%*s%s%*s%b%b║%b\n' \
                "$BCYAN" "$RESET" \
                "$color$BOLD" "$left" '' "$text" "$right" '' \
                "$RESET" "$BCYAN" "$RESET"
}

# Helper: tag list row (wraps long lists across multiple lines)
_info_tags() {
        key="$1"; tags="$2"; kc="${3:-$CYAN}"; vc="${4:-$DIM$WHITE}"
        # Cannot use pipe+while because subshell loses variable state.
        # Use a temp file as line-counter instead.
        _tmp_tag="/tmp/esim_tag_first.$$"
        printf '1' > "$_tmp_tag"
        printf '%s' "$tags" | tr ',' '\n' | while read -r tag; do
                tag="$(printf '%s' "$tag" | sed 's/^ *//;s/ *$//')"
                [ -z "$tag" ] && continue
                if [ "$(cat "$_tmp_tag")" = "1" ]; then
                        printf '%b║%b  %b%-22s%b %b%-38s%b%b║%b\n' \
                                "$BCYAN" "$RESET" \
                                "$kc$BOLD" "$key" "$RESET" \
                                "$vc" "$(trim_text "$tag" 38)" "$RESET" \
                                "$BCYAN" "$RESET"
                        printf '0' > "$_tmp_tag"
                else
                        printf '%b║%b  %b%-22s%b %b%-38s%b%b║%b\n' \
                                "$BCYAN" "$RESET" \
                                "$DIM" "" "$RESET" \
                                "$vc" "$(trim_text "- $tag" 38)" "$RESET" \
                                "$BCYAN" "$RESET"
                fi
        done
        rm -f "$_tmp_tag"
}

show_info() {
        json="$(run_lpac_capture chip info)"
        printf '\n'

        # Extract all fields via jq into tab-separated lines
        fields="$(printf '%s\n' "$json" | jq -r '
                select(type=="object" and .type=="lpa") |
                .payload as $p |
                $p.data as $d |
                $d.EUICCInfo2 as $e |
                [
                        ($p.code | tostring),
                        ($p.message // "-"),
                        ($d.eidValue // "-"),
                        ($d.EuiccConfiguredAddresses.defaultDpAddress // "- (not set)"),
                        ($d.EuiccConfiguredAddresses.rootDsAddress // "-"),
                        ($e.euiccFirmwareVer // "-"),
                        ($e.profileVersion // "-"),
                        ($e.svn // "-"),
                        ($e.ts102241Version // "-"),
                        ($e.globalplatformVersion // "-"),
                        ($e.ppVersion // "-"),
                        ($e.sasAcreditationNumber // "-"),
                        (($e.extCardResource.installedApplication // 0) | tostring),
                        (($e.extCardResource.freeNonVolatileMemory // 0) | tostring),
                        (($e.extCardResource.freeVolatileMemory // 0) | tostring),
                        ($e.uiccCapability // [] | join(",")),
                        ($e.rspCapability // [] | join(",")),
                        ($e.euiccCiPKIdListForVerification // [] | join(",")),
                        ($e.euiccCiPKIdListForSigning // [] | join(",")),
                        ($e.forbiddenProfilePolicyRules // [] | join(","))
                ] | @tsv' 2>/dev/null)"

        if [ -z "$fields" ]; then
                printf '%b  ✘  Gagal membaca chip info. Pastikan lpac berjalan normal.%b\n' "$BRED$BOLD" "$RESET"
                show_raw_if_debug "$json"
                return
        fi

        code="$(     printf '%s' "$fields" | cut -f1)"
        msg="$(      printf '%s' "$fields" | cut -f2)"
        eid="$(      printf '%s' "$fields" | cut -f3)"
        dp_addr="$(  printf '%s' "$fields" | cut -f4)"
        ds_addr="$(  printf '%s' "$fields" | cut -f5)"
        fw_ver="$(   printf '%s' "$fields" | cut -f6)"
        prof_ver="$( printf '%s' "$fields" | cut -f7)"
        svn="$(      printf '%s' "$fields" | cut -f8)"
        ts102="$(    printf '%s' "$fields" | cut -f9)"
        gp_ver="$(   printf '%s' "$fields" | cut -f10)"
        pp_ver="$(   printf '%s' "$fields" | cut -f11)"
        sas_no="$(   printf '%s' "$fields" | cut -f12)"
        inst_app="$( printf '%s' "$fields" | cut -f13)"
        free_nvm="$( printf '%s' "$fields" | cut -f14)"
        free_ram="$( printf '%s' "$fields" | cut -f15)"
        uicc_cap="$( printf '%s' "$fields" | cut -f16)"
        rsp_cap="$(  printf '%s' "$fields" | cut -f17)"
        ci_verify="$(printf '%s' "$fields" | cut -f18)"
        ci_sign="$(  printf '%s' "$fields" | cut -f19)"
        ppr_forbid="$(printf '%s' "$fields" | cut -f20)"

        # Compute NVM percentage label
        # freeNonVolatileMemory of L850GL is typically out of ~1MB (1048576)
        nvm_total=1048576
        nvm_pct=$(( free_nvm * 100 / nvm_total ))
        nvm_label="${free_nvm} bytes  (~${nvm_pct}% free of ~1MB)"
        ram_kb=$(( free_ram / 1024 ))
        ram_label="${free_ram} bytes  (~${ram_kb} KB)"

        # ── Draw box ──────────────────────────────────────────────────────────
        printf '%b╔%s╗%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"
        _info_title "  eUICC / EID  INFO  " "$BCYAN"
        box_center "L850GL  eSIM Manager" "$DIM$ITALIC" "$BCYAN"
        printf '%b╠%s╣%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"

        # Status
        if [ "$code" = "0" ]; then
                _info_kv "Status" "OK - $msg" "$CYAN" "$BGREEN"
        else
                _info_kv "Status" "FAIL - $msg  (code: $code)" "$CYAN" "$BRED"
        fi
        _info_sep

        # EID
        _info_kv "EID" "$eid" "$BYELLOW" "$BYELLOW"
        _info_sep

        # Addresses
        _info_title "-- Server Addresses --" "$BBLUE"
        _info_kv "Default SM-DP+" "$dp_addr" "$CYAN" "$WHITE"
        _info_kv "Root SM-DS"     "$ds_addr" "$CYAN" "$WHITE"
        _info_sep

        # Firmware & versions
        _info_title "-- Firmware & Versions --" "$BBLUE"
        _info_kv "eUICC Firmware"    "$fw_ver"   "$CYAN" "$BGREEN"
        _info_kv "Profile Version"   "$prof_ver" "$CYAN" "$WHITE"
        _info_kv "SVN"               "$svn"      "$CYAN" "$WHITE"
        _info_kv "TS.102.241 Ver"    "$ts102"    "$CYAN" "$WHITE"
        _info_kv "GlobalPlatform Ver" "$gp_ver"  "$CYAN" "$WHITE"
        _info_kv "PP Version"        "$pp_ver"   "$CYAN" "$WHITE"
        _info_kv "SAS Accreditation" "$sas_no"   "$CYAN" "$BMAGENTA"
        _info_sep

        # Memory
        _info_title "-- Memory --" "$BBLUE"
        _info_kv "Installed Apps"  "$inst_app"  "$CYAN" "$WHITE"
        _info_kv "Free NVM"        "$nvm_label" "$CYAN" "$BGREEN"
        _info_kv "Free RAM"        "$ram_label" "$CYAN" "$BGREEN"
        _info_sep

        # Capabilities
        _info_title "-- RSP Capabilities --" "$BBLUE"
        _info_tags "RSP Cap" "$rsp_cap" "$CYAN" "$WHITE"
        _info_sep

        # PPR
        if [ -n "$ppr_forbid" ] && [ "$ppr_forbid" != "-" ]; then
                _info_title "-- Profile Policy Rules --" "$BBLUE"
                _info_kv "Forbidden PPR" "$ppr_forbid" "$CYAN" "$BYELLOW"
                _info_sep
        fi

        # CI Keys (truncated)
        _info_title "-- GSMA CI Public Keys --" "$BBLUE"
        ci_v_short="$(printf '%s' "$ci_verify" | cut -c1-37)..."
        ci_s_short="$(printf '%s' "$ci_sign"   | cut -c1-37)..."
        _info_kv "CI Verify" "$ci_v_short" "$CYAN" "$DIM$WHITE"
        _info_kv "CI Sign"   "$ci_s_short" "$CYAN" "$DIM$WHITE"

        printf '%b╚%s╝%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"

        show_raw_if_debug "$json"
}

# ─── Requirements check ───────────────────────────────────────────────────────

check_requirements() {
        if [ ! -x "$LPAC_BIN" ]; then
                printf '%b  ✘  LPAC tidak ditemukan di %s%b\n' "$BRED$BOLD" "$LPAC_BIN" "$RESET" >&2
                exit 1
        fi
        if ! has_jq; then
                printf '%b  ✘  jq tidak ditemukan. Install: apk add jq%b\n' "$BRED$BOLD" "$RESET" >&2
                exit 1
        fi
}

# ─── Main menu ────────────────────────────────────────────────────────────────

main_menu() {
        clear_screen
        while :; do
                printf '\n'
                printf '%b╔%s╗%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"
                box_center "L850GL  eSIM  Manager" "$BOLD$BCYAN$BG_BLACK" "$BCYAN"
                box_center "lpac  .  openwrt  .  esim" "$DIM$ITALIC" "$BCYAN"
                printf '%b╠%s╣%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"
                box_item "1" "INFO EID & eUICC" "$BOLD$BYELLOW" "$BCYAN" "$BCYAN"
                box_item "2" "Profile List  ( Switch / Delete )" "$BOLD$BYELLOW" "$BMAGENTA" "$BCYAN"
                box_item "3" "Download eSIM Profile" "$BOLD$BYELLOW" "$BGREEN" "$BCYAN"
                box_item "4" "Process Pending Notification" "$BOLD$BYELLOW" "$BBLUE" "$BCYAN"
                box_item "5" "LPAC Version" "$BOLD$BYELLOW" "$WHITE" "$BCYAN"
                box_item "6" "Recovery SIM Missing" "$BOLD$BYELLOW" "$BRED" "$BCYAN"
                printf '%b╠%s╣%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"
                box_item "0" "Exit" "$BOLD$DIM" "$DIM" "$BCYAN"
                printf '%b╚%s╝%b\n' "$BCYAN" "$(repeat_char '═' $((BOX_WIDTH - 2)))" "$RESET"

                printf '\n%b  ➤  Pilih menu: %b' "$BCYAN$BOLD" "$RESET"
                read -r choice

                case "$choice" in
                        1) show_info; pause ;;
                        2) profile_menu ;;
                        3) download_profile ;;
                        4) process_notifications; pause ;;
                        5)
                                json="$(run_lpac_capture version)"
                                show_lpac_summary "LPAC VERSION" "$json"
                                pause ;;
                        6) recover_sim_missing; pause ;;
                        0|q|Q) printf '\n%b  Goodbye.%b\n\n' "$DIM$ITALIC" "$RESET"; exit 0 ;;
                        *) printf '%b  Pilihan tidak dikenal.%b\n' "$BRED" "$RESET"; pause ;;
                esac
        done
}

check_requirements
main_menu
